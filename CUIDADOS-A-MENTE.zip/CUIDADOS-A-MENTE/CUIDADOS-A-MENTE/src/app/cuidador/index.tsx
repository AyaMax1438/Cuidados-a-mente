export { default } from '../painel';
